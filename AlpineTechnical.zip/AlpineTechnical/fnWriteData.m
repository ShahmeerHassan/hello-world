function fnWriteData(math)
    
end